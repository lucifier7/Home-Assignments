﻿namespace DelegateLibrary
{
    
    
}