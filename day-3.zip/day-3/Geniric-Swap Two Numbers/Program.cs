﻿class MainClass
{
    public static void SwapData(string s1, string s2)
    {
        string tempstring = s1;
        s1 = s2;
        s2 = tempstring;
        Console.WriteLine("After Swaping s1:" + s1);
        Console.WriteLine("After Swaping s2:" + s2);
    }

    public static void Swapint(int i1, int i2)
    {
        i1 = i1 + i2;
        i2 = i1 - i2;
        i1 = i1 - i2;
        Console.WriteLine("After Swaping i1:" + i1);
        Console.WriteLine("After Swaping i2:" + i2);
    }
    public static void Main()
    {
        //int temp;
        Console.WriteLine("Enter i1:");
        int i1 = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter i2:");
        int i2 = int.Parse(Console.ReadLine());
        Console.WriteLine("Before Swaping i1:"+i1);
        Console.WriteLine("Before Swaping i2:" + i2);

        Swapint(i1, i2);
        





        string tempstring;
        Console.WriteLine("Enter s1:");
        string s1 = Console.ReadLine();
        Console.WriteLine("Enter s1:");
        string s2 = Console.ReadLine();
        Console.WriteLine("Before Swaping s1:" + s1);
        Console.WriteLine("Before Swaping s2:" + s2);

        SwapData(s1,s2);
        
    }
}
